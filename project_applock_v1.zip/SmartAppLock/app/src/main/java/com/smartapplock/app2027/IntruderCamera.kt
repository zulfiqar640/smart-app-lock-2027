package com.smartapplock.app2027

import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

/** Front camera se bina preview ke ek photo leta hai. */
class IntruderCamera(private val activity: AppCompatActivity) {

    fun dir(): File = File(activity.filesDir, "intruders").also { it.mkdirs() }

    fun capture(attempt: Int) {
        if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val future = ProcessCameraProvider.getInstance(activity)
            future.addListener({
                try {
                    val provider = future.get()
                    val selector = when {
                        provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) -> CameraSelector.DEFAULT_FRONT_CAMERA
                        provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) -> return@addListener
                        else -> return@addListener
                    }
                    val imageCapture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build()
                    provider.unbindAll()
                    provider.bindToLifecycle(activity, selector, imageCapture)
                    // camera ko exposure ke liye thora waqt dein
                    Handler(Looper.getMainLooper()).postDelayed({
                        val file = File(dir(), "intruder_${System.currentTimeMillis()}_$attempt.jpg")
                        val opts = ImageCapture.OutputFileOptions.Builder(file).build()
                        imageCapture.takePicture(
                            opts,
                            ContextCompat.getMainExecutor(activity),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                                    provider.unbindAll()
                                }
                                override fun onError(e: ImageCaptureException) {
                                    provider.unbindAll()
                                }
                            }
                        )
                    }, 500)
                } catch (_: Exception) {
                }
            }, ContextCompat.getMainExecutor(activity))
        } catch (_: Exception) {
        }
    }
}
