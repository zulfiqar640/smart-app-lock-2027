package com.smartapplock.app2027

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {

    private lateinit var store: PinStore
    private lateinit var camera: IntruderCamera
    private lateinit var title: TextView
    private lateinit var dots: TextView
    private lateinit var info: TextView
    private val entered = StringBuilder()
    private var setupFirst: String? = null
    private var setupMode = false
    private var changeMode = false
    private var timer: CountDownTimer? = null
    private val keys = ArrayList<Button>()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) Toast.makeText(this, R.string.camera_hint, Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        store = PinStore(this)
        camera = IntruderCamera(this)
        changeMode = intent.getBooleanExtra("change", false) && Session.unlocked
        setupMode = !store.hasPin() || changeMode
        buildUi()
        if (setupMode) {
            title.setText(R.string.set_pin)
            permLauncher.launch(android.Manifest.permission.CAMERA)
        } else {
            title.setText(R.string.enter_pin)
        }
    }

    override fun onResume() {
        super.onResume()
        if (!setupMode) {
            startLockoutIfNeeded()
            if (store.biometricEnabled && !isLockedOut()) showBiometric()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        title = label("", 20f, getColor(R.color.text), true)
        dots = label("", 34f, getColor(R.color.accent), true).apply { setPadding(0, dp(20), 0, dp(8)) }
        info = label("", 14f, getColor(R.color.danger), true).apply { minHeight = dp(40) }
        root.addView(title)
        root.addView(dots)
        root.addView(info)

        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("⌫", "0", "✓")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) {
                val b = Button(this).apply {
                    text = k
                    textSize = 24f
                    setTextColor(getColor(R.color.text))
                    background = roundBg(getColor(R.color.card), 40)
                    stateListAnimator = null
                    setOnClickListener { onKey(k, this) }
                }
                val lp = LinearLayout.LayoutParams(0, dp(68), 1f)
                lp.setMargins(dp(6), dp(6), dp(6), dp(6))
                row.addView(b, lp)
                keys.add(b)
            }
            root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        if (!setupMode) {
            val fp = styledButton(getString(R.string.use_fingerprint)).apply {
                setOnClickListener { if (store.biometricEnabled) showBiometric() }
            }
            root.addView(fp)
        }
        setContentView(root)
        refreshDots()
    }

    private fun refreshDots() {
        dots.text = if (entered.isEmpty()) " " else "●".repeat(entered.length)
    }

    private fun onKey(k: String, v: android.view.View) {
        if (isLockedOut()) return
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        info.text = ""
        when (k) {
            "⌫" -> if (entered.isNotEmpty()) entered.deleteCharAt(entered.length - 1)
            "✓" -> submit()
            else -> {
                if (entered.length < 6) entered.append(k)
                if (!setupMode && entered.length == store.pinLength) {
                    refreshDots()
                    submit()
                    return
                }
            }
        }
        refreshDots()
    }

    private fun submit() {
        val pin = entered.toString()
        if (setupMode) {
            if (pin.length < 4) {
                info.setText(R.string.pin_short)
                return
            }
            val first = setupFirst
            if (first == null) {
                setupFirst = pin
                entered.clear()
                title.setText(R.string.confirm_pin)
                refreshDots()
            } else if (first == pin) {
                store.setPin(pin)
                Toast.makeText(this, R.string.pin_saved, Toast.LENGTH_SHORT).show()
                Session.unlocked = true
                if (changeMode) finish() else openHome()
            } else {
                setupFirst = null
                entered.clear()
                title.setText(R.string.set_pin)
                info.setText(R.string.pin_mismatch)
                refreshDots()
            }
            return
        }
        if (store.check(pin)) {
            store.fails = 0
            Session.unlocked = true
            openHome()
        } else {
            onWrongPin()
        }
    }

    private fun onWrongPin() {
        val n = store.fails + 1
        store.fails = n
        if (store.selfieEnabled) camera.capture(n)
        entered.clear()
        refreshDots()
        info.text = getString(R.string.wrong_pin, n)
        if (n >= 3) {
            store.lockUntil = System.currentTimeMillis() + 30_000L
            store.fails = 0
            startLockoutIfNeeded()
        }
    }

    private fun isLockedOut() = System.currentTimeMillis() < store.lockUntil

    private fun startLockoutIfNeeded() {
        timer?.cancel()
        val remain = store.lockUntil - System.currentTimeMillis()
        if (remain <= 0) {
            keys.forEach { it.isEnabled = true; it.alpha = 1f }
            return
        }
        keys.forEach { it.isEnabled = false; it.alpha = 0.4f }
        timer = object : CountDownTimer(remain, 1000) {
            override fun onTick(ms: Long) {
                info.text = getString(R.string.locked_wait, (ms / 1000).toInt() + 1)
            }
            override fun onFinish() {
                info.text = ""
                keys.forEach { it.isEnabled = true; it.alpha = 1f }
            }
        }.start()
    }

    private fun showBiometric() {
        val can = BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    store.fails = 0
                    Session.unlocked = true
                    openHome()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_title))
            .setNegativeButtonText(getString(R.string.use_pin))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }

    private fun openHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
