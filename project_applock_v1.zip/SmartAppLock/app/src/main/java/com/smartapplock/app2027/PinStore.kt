package com.smartapplock.app2027

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

object Session {
    @Volatile var unlocked = false
    @Volatile var navigating = false
}

class PinStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.getString("hash", null) != null
    val pinLength: Int get() = prefs.getInt("len", 4)

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(pin, salt))
            .putInt("len", pin.length)
            .putInt("fails", 0)
            .putLong("lock_until", 0L)
            .apply()
    }

    fun check(pin: String): Boolean {
        val saltB64 = prefs.getString("salt", null) ?: return false
        val expected = prefs.getString("hash", null) ?: return false
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
    }

    private fun hash(pin: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        // thora sa stretching
        var d = md.digest(pin.toByteArray())
        repeat(5000) { d = MessageDigest.getInstance("SHA-256").digest(d + salt) }
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    var fails: Int
        get() = prefs.getInt("fails", 0)
        set(v) { prefs.edit().putInt("fails", v).apply() }

    var lockUntil: Long
        get() = prefs.getLong("lock_until", 0L)
        set(v) { prefs.edit().putLong("lock_until", v).apply() }

    var selfieEnabled: Boolean
        get() = prefs.getBoolean("selfie", true)
        set(v) { prefs.edit().putBoolean("selfie", v).apply() }

    var biometricEnabled: Boolean
        get() = prefs.getBoolean("bio", false)
        set(v) { prefs.edit().putBoolean("bio", v).apply() }
}
