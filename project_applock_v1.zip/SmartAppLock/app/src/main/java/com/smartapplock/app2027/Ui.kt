package com.smartapplock.app2027

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.roundBg(color: Int, radiusDp: Int = 14): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

fun Context.styledButton(text: String, bg: Int = getColor(R.color.card), fg: Int = getColor(R.color.text)): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 16f
        setTextColor(fg)
        background = roundBg(bg)
        stateListAnimator = null
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54))
        lp.setMargins(0, dp(6), 0, dp(6))
        layoutParams = lp
    }

fun Context.label(text: String, sizeSp: Float = 16f, color: Int = getColor(R.color.text), center: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (center) gravity = Gravity.CENTER
    }

val Int.withAlpha: Int get() = Color.argb(60, Color.red(this), Color.green(this), Color.blue(this))
