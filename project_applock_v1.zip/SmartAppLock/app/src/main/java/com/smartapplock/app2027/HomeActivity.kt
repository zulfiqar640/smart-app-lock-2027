package com.smartapplock.app2027

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.io.File

class HomeActivity : AppCompatActivity() {

    private lateinit var store: PinStore
    private lateinit var intruderBtn: android.widget.Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        store = PinStore(this)
        if (!Session.unlocked) {
            goLock(); return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(label(getString(R.string.home_title), 26f, getColor(R.color.accent)))
        root.addView(label(" ", 8f))

        val selfie = SwitchCompat(this).apply {
            text = getString(R.string.intruder_selfie)
            setTextColor(getColor(R.color.text))
            textSize = 16f
            isChecked = store.selfieEnabled
            setPadding(0, dp(14), 0, dp(14))
            setOnCheckedChangeListener { _, c -> store.selfieEnabled = c }
        }
        val bio = SwitchCompat(this).apply {
            text = getString(R.string.fingerprint_unlock)
            setTextColor(getColor(R.color.text))
            textSize = 16f
            isChecked = store.biometricEnabled
            setPadding(0, dp(14), 0, dp(14))
            setOnCheckedChangeListener { _, c -> store.biometricEnabled = c }
        }
        root.addView(selfie)
        root.addView(bio)

        intruderBtn = styledButton("").apply {
            setOnClickListener { Session.navigating = true; startActivity(Intent(this@HomeActivity, IntruderActivity::class.java)) }
        }
        root.addView(intruderBtn)
        root.addView(styledButton(getString(R.string.change_pin)).apply {
            setOnClickListener {
                Session.navigating = true
                startActivity(Intent(this@HomeActivity, LockActivity::class.java).putExtra("change", true))
            }
        })
        root.addView(styledButton(getString(R.string.lock_now), getColor(R.color.accent), getColor(R.color.bg)).apply {
            setOnClickListener { goLock() }
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Session.navigating = false
        if (!Session.unlocked) { goLock(); return }
        val n = File(filesDir, "intruders").listFiles()?.size ?: 0
        if (::intruderBtn.isInitialized) intruderBtn.text = getString(R.string.intruders, n)
    }

    override fun onStop() {
        super.onStop()
        // app background mein jaye to dobara lock ho jaye
        if (!isChangingConfigurations && !Session.navigating) Session.unlocked = false
    }

    private fun goLock() {
        Session.unlocked = false
        startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
