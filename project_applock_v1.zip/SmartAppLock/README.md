# Smart App Lock 2027

PIN lock + intruder selfie (galat PIN par front camera se photo), 3 galat attempts ke baad 30 second lockout,
fingerprint option, Urdu/English interface.

Package: com.smartapplock.app2027
Build: GitHub Actions (.github/workflows/build.yml) -> Releases mein SmartAppLock-debug.apk
