package com.smartapplock.app2027

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class AppsActivity : AppCompatActivity() {

    private class Item(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var store: PinStore
    private lateinit var status: TextView
    private lateinit var listView: ListView
    private val items = ArrayList<Item>()
    private val locked = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySecure()
        if (!Session.unlocked) { finish(); return }
        store = PinStore(this)
        locked.addAll(store.lockedApps)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(8))
        }
        root.addView(label(getString(R.string.apps_title), 24f, getColor(R.color.accent)))
        status = label(getString(R.string.loading), 14f, getColor(R.color.muted)).apply {
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)
        listView = ListView(this).apply {
            divider = null
            adapter = Adapter()
        }
        root.addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { Item(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                items.clear()
                items.addAll(found)
                (listView.adapter as BaseAdapter).notifyDataSetChanged()
                status.text = ""
            }
        }.start()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !isFinishing) Session.unlocked = false
    }

    override fun onResume() {
        super.onResume()
        if (!Session.unlocked) finish()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView == null) {
                row = LinearLayout(this@AppsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                row.addView(ImageView(this@AppsActivity).apply { id = 1001 }, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(
                    TextView(this@AppsActivity).apply {
                        id = 1002
                        textSize = 16f
                        setTextColor(getColor(R.color.text))
                        setPadding(dp(12), 0, dp(8), 0)
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                )
                row.addView(SwitchCompat(this@AppsActivity).apply { id = 1003 })
            } else {
                row = convertView as LinearLayout
            }
            val item = items[position]
            row.findViewById<ImageView>(1001).setImageDrawable(item.icon)
            row.findViewById<TextView>(1002).text = item.label
            val sw = row.findViewById<SwitchCompat>(1003)
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = locked.contains(item.pkg)
            sw.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
                if (checked) locked.add(item.pkg) else locked.remove(item.pkg)
                store.lockedApps = locked
            }
            return row
        }
    }
}
