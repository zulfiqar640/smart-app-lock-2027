package com.smartapplock.app2027

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import java.io.File

class HomeActivity : AppCompatActivity() {

    private lateinit var store: PinStore
    private lateinit var intruderBtn: Button
    private lateinit var appsBtn: Button
    private lateinit var usageBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var protect: SwitchCompat
    private var ready = false
    private var building = false

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startGuard() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySecure()
        store = PinStore(this)
        if (!Session.unlocked) {
            goLock(); return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(label(getString(R.string.home_title), 26f, getColor(R.color.accent)))
        root.addView(label(" ", 8f))

        // 1) Ijazatein
        root.addView(label(getString(R.string.step_perms), 13f, getColor(R.color.muted)))
        usageBtn = styledButton("").apply {
            setOnClickListener { openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        overlayBtn = styledButton("").apply {
            setOnClickListener {
                openSettings(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        root.addView(usageBtn)
        root.addView(overlayBtn)
        root.addView(styledButton(getString(R.string.battery_btn)).apply {
            setOnClickListener { openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })

        // 2) Apps chunein + protection
        root.addView(label(getString(R.string.step_apps), 13f, getColor(R.color.muted)).apply {
            setPadding(0, dp(12), 0, 0)
        })
        appsBtn = styledButton("").apply {
            setOnClickListener {
                Session.navigating = true
                startActivity(Intent(this@HomeActivity, AppsActivity::class.java))
            }
        }
        root.addView(appsBtn)

        protect = SwitchCompat(this).apply {
            text = getString(R.string.protection_switch)
            setTextColor(getColor(R.color.text))
            textSize = 17f
            setPadding(0, dp(14), 0, dp(14))
        }
        protect.setOnCheckedChangeListener { v, checked ->
            if (building) return@setOnCheckedChangeListener
            if (checked) {
                if (!Perms.hasUsage(this) || !Perms.hasOverlay(this)) {
                    building = true
                    v.isChecked = false
                    building = false
                    Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                store.protectionEnabled = true
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    startGuard()
                }
            } else {
                store.protectionEnabled = false
                stopService(Intent(this, GuardService::class.java))
            }
        }
        root.addView(protect)

        // 3) Baqi settings
        root.addView(label(getString(R.string.step_more), 13f, getColor(R.color.muted)).apply {
            setPadding(0, dp(12), 0, 0)
        })
        root.addView(SwitchCompat(this).apply {
            text = getString(R.string.intruder_selfie)
            setTextColor(getColor(R.color.text))
            textSize = 16f
            isChecked = store.selfieEnabled
            setPadding(0, dp(14), 0, dp(14))
            setOnCheckedChangeListener { _, c -> store.selfieEnabled = c }
        })
        root.addView(SwitchCompat(this).apply {
            text = getString(R.string.fingerprint_unlock)
            setTextColor(getColor(R.color.text))
            textSize = 16f
            isChecked = store.biometricEnabled
            setPadding(0, dp(14), 0, dp(14))
            setOnCheckedChangeListener { _, c -> store.biometricEnabled = c }
        })
        intruderBtn = styledButton("").apply {
            setOnClickListener {
                Session.navigating = true
                startActivity(Intent(this@HomeActivity, IntruderActivity::class.java))
            }
        }
        root.addView(intruderBtn)
        root.addView(styledButton(getString(R.string.change_pin)).apply {
            setOnClickListener {
                Session.navigating = true
                startActivity(Intent(this@HomeActivity, LockActivity::class.java).putExtra("change", true))
            }
        })
        root.addView(styledButton(getString(R.string.lock_now), getColor(R.color.accent), getColor(R.color.bg)).apply {
            setOnClickListener { goLock() }
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        ready = true
    }

    override fun onResume() {
        super.onResume()
        Session.navigating = false
        if (!Session.unlocked) { goLock(); return }
        if (ready) refresh()
    }

    private fun refresh() {
        val u = Perms.hasUsage(this)
        val o = Perms.hasOverlay(this)
        val on = "ON ✓"
        val off = getString(R.string.perm_missing)
        usageBtn.text = getString(R.string.perm_usage) + ": " + (if (u) on else off)
        overlayBtn.text = getString(R.string.perm_overlay) + ": " + (if (o) on else off)
        val n = File(filesDir, "intruders").listFiles()?.size ?: 0
        intruderBtn.text = getString(R.string.intruders, n)
        appsBtn.text = getString(R.string.choose_apps, store.lockedApps.size)
        building = true
        protect.isChecked = store.protectionEnabled && u && o
        building = false
        if (protect.isChecked) startGuard()
    }

    private fun startGuard() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, GuardService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun openSettings(i: Intent) {
        Session.navigating = true
        try {
            startActivity(i)
        } catch (_: Exception) {
            Session.navigating = false
        }
    }

    override fun onStop() {
        super.onStop()
        // app background mein jaye to dobara lock ho jaye
        if (!isChangingConfigurations && !Session.navigating) Session.unlocked = false
    }

    private fun goLock() {
        Session.unlocked = false
        startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
