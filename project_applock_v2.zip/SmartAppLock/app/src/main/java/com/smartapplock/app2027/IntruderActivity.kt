package com.smartapplock.app2027

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.DateFormat
import java.util.Date

class IntruderActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySecure()
        if (!Session.unlocked) { finish(); return }
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        scroll.addView(list)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (!Session.unlocked) { finish(); return }
        render()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !isFinishing) Session.unlocked = false
    }

    private fun files(): List<File> =
        (File(filesDir, "intruders").listFiles() ?: emptyArray())
            .filter { it.name.endsWith(".jpg") }
            .sortedByDescending { it.name }

    private fun render() {
        list.removeAllViews()
        list.addView(label(getString(R.string.intruders_title), 24f, getColor(R.color.accent)))
        val all = files()
        if (all.isEmpty()) {
            list.addView(label("\n" + getString(R.string.no_intruders), 15f, getColor(R.color.muted)))
            return
        }
        list.addView(styledButton(getString(R.string.clear_all), getColor(R.color.danger), getColor(R.color.bg)).apply {
            setOnClickListener { files().forEach { it.delete() }; render() }
        })
        for (f in all) {
            val parts = f.nameWithoutExtension.split("_")
            val time = parts.getOrNull(1)?.toLongOrNull() ?: f.lastModified()
            val attempt = parts.getOrNull(2)?.toIntOrNull() ?: 0
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundBg(getColor(R.color.card))
                setPadding(dp(12), dp(12), dp(12), dp(12))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, dp(10), 0, dp(4))
                layoutParams = lp
            }
            val bmp = loadBitmap(f)
            if (bmp != null) {
                val iv = ImageView(this).apply {
                    setImageBitmap(bmp)
                    adjustViewBounds = true
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }
                card.addView(iv)
            }
            val ts = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(Date(time))
            card.addView(label(ts, 15f).apply { setPadding(0, dp(8), 0, 0) })
            if (attempt > 0) card.addView(label(getString(R.string.attempt_n, attempt), 13f, getColor(R.color.muted)))
            card.addView(styledButton(getString(R.string.delete), getColor(R.color.bg), getColor(R.color.danger)).apply {
                setOnClickListener { f.delete(); render() }
            })
            list.addView(card)
        }
    }

    private fun loadBitmap(f: File): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            val bmp = BitmapFactory.decodeFile(f.absolutePath, opts) ?: return null
            val orientation = ExifInterface(f.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        } catch (e: Exception) {
            null
        }
    }
}
