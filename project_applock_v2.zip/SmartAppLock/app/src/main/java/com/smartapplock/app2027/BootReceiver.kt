package com.smartapplock.app2027

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            if (PinStore(context).protectionEnabled && Perms.hasUsage(context) && Perms.hasOverlay(context)) {
                ContextCompat.startForegroundService(context, Intent(context, GuardService::class.java))
            }
        } catch (_: Exception) {
        }
    }
}
