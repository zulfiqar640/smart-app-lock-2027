package com.smartapplock.app2027

/** Doosre app ke upar aane wali lock screen. Saara kaam LockActivity karti hai. */
class GuardActivity : LockActivity() {
    override val guardMode: Boolean get() = true
}
