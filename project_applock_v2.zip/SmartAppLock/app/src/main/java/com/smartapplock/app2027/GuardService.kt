package com.smartapplock.app2027

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Background mein dekhta rehta hai ke kaunsa app samne khula hai.
 * Agar wo "locked" list mein hai to GuardActivity (PIN screen) upar le aata hai.
 */
class GuardService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: PinStore
    private lateinit var usm: UsageStatsManager
    private var lastFg: String? = null
    private var lastQuery = 0L
    private var lastLaunch = 0L
    private var running = false

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent?) {
            // screen band hote hi sab apps dobara lock
            Session.unlockedPkgs.clear()
            lastFg = null
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                check()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = PinStore(this)
        usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showNotification()
        if (!store.protectionEnabled) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            lastQuery = System.currentTimeMillis() - 2000
            handler.post(tick)
        }
        return START_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("guard", "Protection", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, "guard")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun check() {
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(lastQuery - 1000, now)
        lastQuery = now
        val e = UsageEvents.Event()
        var fg: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                val p = e.packageName
                if (p != "com.android.systemui") fg = p
            }
        }
        val me = packageName
        if (fg != null && fg != lastFg) {
            val prev = lastFg
            lastFg = fg
            // user locked app chhor kar kahin aur chala gaya -> wo app dobara lock
            if (prev != null && prev != me && fg != me) Session.unlockedPkgs.remove(prev)
        }
        val cur = lastFg ?: return
        if (cur == me) return
        if (!store.lockedApps.contains(cur)) return
        if (Session.unlockedPkgs.contains(cur)) return
        if (now - lastLaunch < 800) return
        if (Session.guardShowing && Session.guardPkg == cur) return
        lastLaunch = now
        Session.guardPkg = cur
        try {
            startActivity(
                Intent(this, GuardActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
